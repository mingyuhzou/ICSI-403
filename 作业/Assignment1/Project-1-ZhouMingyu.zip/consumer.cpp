#include <iostream>
#include <fstream>
#include <bitset>
#include <string>
#include <vector>

using namespace std;

const int MAX_MESSAGE_SIZE = 5;        // Max characters per block
const string SYN = "0001011000010110"; // Odd parity encoding of ASCII 22 (SYN)

// Encode a character with odd parity
string encodeWithParity(char c)
{
    bitset<7> bits(c);
    int parity = bits.count() % 2 == 0 ? 1 : 0;      // Calculate parity bit
    return bitset<8>((parity << 7) | c).to_string(); // Combine parity and data
}

// Encode input file and save to binary file
void encodeInputFile(const string &inputFile, const string &outputFile)
{
    ifstream in(inputFile);
    ofstream out(outputFile);
    vector<string> block; // Store encoded characters
    char c;

    while (in.get(c))
    {
        if (c == '<')
            break; // Stop if '<' is encountered

        block.push_back(encodeWithParity(c)); // Encode and add to block

        if (block.size() == MAX_MESSAGE_SIZE) // If block is full
        {
            out << SYN;                            // Write SYN marker
            out << encodeWithParity(block.size()); // Write block size
            for (const auto &encodedChar : block)
                out << encodedChar; // Write characters
            block.clear();          // Clear block
        }
    }

    // Write remaining characters if any
    if (!block.empty())
    {
        out << SYN;
        out << encodeWithParity(block.size());
        for (const auto &encodedChar : block)
            out << encodedChar;
    }
}

// Decode an 8-bit character with odd parity
char decodeWithParity(const string &encodedChar)
{
    string dataBits = encodedChar.substr(1, 7); // Extract 7 data bits
    bitset<7> bits(dataBits);
    return static_cast<char>(bits.to_ulong()); // Convert to character
}

// Decode binary file and save to text file
void decodeResultFile(const string &inputFile, const string &outputFile)
{
    ifstream in(inputFile);
    ofstream out(outputFile);

    string content((istreambuf_iterator<char>(in)), {}); // Read file content
    string buffer;

    // Filter non-binary characters
    for (char c : content)
        if (c == '0' || c == '1')
            buffer += c;

    size_t pos = 0;
    while ((pos = buffer.find(SYN)) != string::npos) // Find SYN marker
    {
        buffer = buffer.substr(pos + 16); // Skip SYN

        if (buffer.size() < 8)
            break; // Check if enough bits remain

        string lengthEncoded = buffer.substr(0, 8);      // Extract block size
        int blockSize = decodeWithParity(lengthEncoded); // Decode block size
        buffer = buffer.substr(8);                       // Remove block size from buffer

        for (int i = 0; i < blockSize; i++) // Decode each character in block
        {
            if (buffer.size() < 8)
                break;

            string encodedChar = buffer.substr(0, 8); // Extract character
            buffer = buffer.substr(8);                // Remove character from buffer

            char decodedChar = decodeWithParity(encodedChar); // Decode character
            out.put(decodedChar);                             // Write to output file
        }
    }
}

int main()
{
    int choice;
    string inputFile, outputFile;

    cout << "Choose operation (0-encode, 1-decode): ";
    cin >> choice;

    if (choice == 0) // Encode
    {
        cout << "Enter input file name: ";
        cin >> inputFile;
        outputFile = "project1Bin_binf.txt"; // Output binary file
        encodeInputFile(inputFile, outputFile);
        cout << "Encoding complete. Result saved in " << outputFile << endl;
    }
    else if (choice == 1) // Decode
    {
        inputFile = "project1Result_outf.txt";  // Input binary file
        outputFile = "project1Result_done.txt"; // Output text file
        decodeResultFile(inputFile, outputFile);
        cout << "Decoding complete. Result saved in " << outputFile << endl;
    }
    else
    {
        cout << "Invalid choice!" << endl;
    }

    return 0;
}